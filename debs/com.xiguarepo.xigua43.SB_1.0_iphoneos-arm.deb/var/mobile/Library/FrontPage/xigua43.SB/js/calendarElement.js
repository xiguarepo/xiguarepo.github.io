(function(window, doc) {

    var addedCalendars = [];

    function removeCalendar() {
        var addedStyles = ['weekendbackgroundcolor', 'weekendtextcolor','dayofweekwidth', 'daysize', 'dayofweekbottommargin', 'dayofweektopmargin', 'dayofweekfontweight', 'daycolor', 'numbersize', 'bgwidth', 'bgheight', 'daynumberfontweight', 'numbercolor', 'numberbgcolor', 'calradius', 'numberstrokecolor', 'todaynumberfontweight', 'todaysize', 'todaytextcolor', 'todaystrokecolor', 'todaybgcolor', 'extrasize', 'fillcolor', 'fillbgcolor'],
        styleID, i, styleDOM;
        for (i = 0; i < addedStyles.length; i++) {
                styleID = addedStyles[i];
                styleDOM = doc.getElementById(styleID);
            if (styleDOM) {
                doc.body.removeChild(styleDOM);
            }
        }
        addedStyles = null;
    }

    function createCalendar(div){
        div.innerHTML = '';
        var calendarize = new Calendarize();
        var dateInfo = new Date();
        var info = calendarize.buildMonth(dateInfo.getMonth(), dateInfo.getFullYear(), {
            showMonth: false,
            showDaysOfWeek: true,
        });
        div.appendChild(info);
        if(!addedCalendars.includes(div.id)){
            addedCalendars.push(div.id);
        }
    }

    /* Removes current calendar and makes another */
    function updateCalendar(){
        var calendar = element = i = null;
        for (i = 0; i < addedCalendars.length; i++) {
            calendar = addedCalendars[i];
            element = document.getElementById(calendar);
            if(element){
                index = addedCalendars.indexOf(calendar);
                addedCalendars.splice(index, 1);
                element.innerHTML = "";
                createCalendar(element);
            }
        }
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.create = function(div) {
            return createCalendar(div);
        };
        externalMethods.remove = function() {
            removeCalendar();
        };
        externalMethods.update = function() {
            updateCalendar();
        };
        return externalMethods;
    }
    window.calendarElement = initExternalMethods();
}(window, document));
