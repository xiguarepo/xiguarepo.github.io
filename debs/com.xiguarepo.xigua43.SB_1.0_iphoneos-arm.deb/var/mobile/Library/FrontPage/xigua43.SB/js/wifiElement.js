var TESTING = null;
(function(window, doc) {

    var wifiElements = {
        paths: {
            thirdline: {
                elName: "wifi2",
                el: null
            },
            secondline: {
                elName: "wifi1",
                el: null
            },
            topline: {
                elName: "wifi3",
                el: null,
            },
        }
    };
    var wifiBG = {
        paths: {
            thirdline: {
                elName: "wifi2",
                el: null
            },
            secondline: {
                elName: "wifi1",
                el: null
            },
            topline: {
                elName: "wifi3",
                el: null,
            },
        }
    }

    function reset(){
        var refObj = wifiElements.paths;
        Object.keys(refObj).forEach(function(key){
            refObj[key]['elName'] = null;
        });
    }

    function getElementPaths() {
        var svg = this.getSVGDocument();
        var refObj = wifiElements.paths;
        Object.keys(refObj).forEach(function(key){
            var elementName = refObj[key]['elName'];
            var el = svg.getElementById(elementName);
            if(el){
                refObj[key]['el'] = el;
            }
        });
        update(2);
        // refObj.topline.el.style.fill = 'green';
        // refObj.secondline.el.style.fill = 'green';
        // refObj.thirdline.el.style.fill = 'green';
        // refObj.dot.el.style.fill = 'green';
    }

    function getElementBGPaths() {
        var svg = this.getSVGDocument();
        var refObj = wifiBG.paths;
        Object.keys(refObj).forEach(function(key){
            var elementName = refObj[key]['elName'];
            var el = svg.getElementById(elementName);
            if(el){
                refObj[key]['el'] = el;
            }
        });
        refObj.topline.el.style.fill = 'rgba(255,255,255,0.2)';
        refObj.secondline.el.style.fill = 'rgba(255,255,255,0.2)';
        refObj.thirdline.el.style.fill = 'rgba(255,255,255,0.2)';
        //refObj.dot.el.style.fill = 'rgba(255,255,255,0.2)';
    }

    function updateStyles(name, value){
        if(name === 'color'){
            if(wifiElements.paths.topline.el){
                wifiElements.paths.topline.el.style.fill = value;
                wifiElements.paths.secondline.el.style.fill = value;
                wifiElements.paths.thirdline.el.style.fill = value;
            }else{
                setTimeout(function(){
                    updateStyles(name, value);
                },200);
            }
        }else if(name === 'colorbg'){
            if(wifiBG.paths.topline.el){
                wifiBG.paths.topline.el.style.fill = value;
                wifiBG.paths.secondline.el.style.fill = value;
                wifiBG.paths.thirdline.el.style.fill = value;
            }else{
                setTimeout(function(){
                    updateStyles(name, value);
                },200);
            }
        }
    }
    

    function update(value){
        switch (String(value)) {
            case '1':
                wifiElements.paths['topline'].el.style.opacity = '0';
                wifiElements.paths['secondline'].el.style.opacity = '0';
                wifiElements.paths['thirdline'].el.style.opacity = '1';
                break;
            case '2':
                wifiElements.paths['topline'].el.style.opacity = '0';
                wifiElements.paths['secondline'].el.style.opacity = '1';
                wifiElements.paths['thirdline'].el.style.opacity = '1';
                break;
            case '3':
                wifiElements.paths['topline'].el.style.opacity = '1';
                wifiElements.paths['secondline'].el.style.opacity = '1';
                wifiElements.paths['thirdline'].el.style.opacity = '1';
                break;
            case '0':
                wifiElements.paths['topline'].el.style.opacity = '0';
                wifiElements.paths['secondline'].el.style.opacity = '0';
                wifiElements.paths['thirdline'].el.style.opacity = '0';
                break;
        
            default:
                break;
        }
    }

    function createElement(div){
        var container = document.createElement('object');
        var container2 = document.createElement('object');
        container.setAttribute('type', 'image/svg+xml');
        container.data = 'images/wifi.svg';
        container.style.pointerEvents = 'none';
        container.id = div.id + "SVG";

        container2.style.position = 'absolute';
        container2.setAttribute('type', 'image/svg+xml');
        container2.data = 'images/wifi.svg';
        container2.style.pointerEvents = 'none';
        container2.id = div.id + "SVG2";
        container2.style.position = 'absolute';
        container2.style.left = '0';
        container2.style.zIndex = '-1';

        div.appendChild(container);
        div.appendChild(container2);
        container.addEventListener("load", getElementPaths, this);
        container2.addEventListener("load", getElementBGPaths, this);

    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.create = function(div) {
            return createElement(div);
        };
        externalMethods.updateStyles = function(name, value){
            return updateStyles(name, value);
        };
        externalMethods.getWifiElements = function () {
            return wifiElements;
        }
        externalMethods.update = function (value) {
            update(value);
        }
        externalMethods.remove = function() {
            reset();
        };
        return externalMethods;
    }
    window.wifiElement = initExternalMethods();
}(window, document));


/* Signal Element */
(function(window, doc) {

    var signalElements = {
        paths: {
            first: {
                elName: "sig1",
                el: null
            },
            second: {
                elName: "sig2",
                el: null
            },
            third: {
                elName: "sig3",
                el: null,
            },
            fourth:{
                elName: "sig4",
                el: null
            }
        }
    };

    var signalBG = {
        paths: {
            first: {
                elName: "sig1",
                el: null
            },
            second: {
                elName: "sig2",
                el: null
            },
            third: {
                elName: "sig3",
                el: null,
            },
            fourth:{
                elName: "sig4",
                el: null
            }
        }
    };

    function reset(){
        var refObj = signalElements.paths;
        Object.keys(refObj).forEach(function(key){
            refObj[key]['elName'] = null;
        });
    }

    function getElementPaths() {
        var svg = this.getSVGDocument();
        var refObj = signalElements.paths;
        Object.keys(refObj).forEach(function(key){
            var elementName = refObj[key]['elName'];
            var el = svg.getElementById(elementName);
            if(el){
                refObj[key]['el'] = el;
            }
        });
        update(2);
    }

    function getElementBGPaths() {
        var svg = this.getSVGDocument();
        var refObj = signalBG.paths;
        Object.keys(refObj).forEach(function(key){
            var elementName = refObj[key]['elName'];
            var el = svg.getElementById(elementName);
            if(el){
                refObj[key]['el'] = el;
            }
        });
        refObj.third.el.style.fill = 'rgba(255,255,255,0.2)';
        refObj.first.el.style.fill = 'rgba(255,255,255,0.2)';
        refObj.second.el.style.fill = 'rgba(255,255,255,0.2)';
        refObj.fourth.el.style.fill = 'rgba(255,255,255,0.2)';
    }

    function updateStyles(name, value){
        if(name === 'color'){
            if(signalElements.paths.first.el){
                signalElements.paths.first.el.style.fill = value;
                signalElements.paths.second.el.style.fill = value;
                signalElements.paths.third.el.style.fill = value;
                signalElements.paths.fourth.el.style.fill = value;
            }else{
                setTimeout(function(){
                    updateStyles(name, value);
                },200);
            }
        }else if (name === 'colorbg'){
            if(signalBG.paths.first.el){
                signalBG.paths.first.el.style.fill = value;
                signalBG.paths.second.el.style.fill = value;
                signalBG.paths.third.el.style.fill = value;
                signalBG.paths.fourth.el.style.fill = value;
            }else{
                setTimeout(function(){
                    updateStyles(name, value);
                },200);
            }
        }
    }
    

    function update(value){
        switch (String(value)) {
            case '0':
                signalElements.paths['first'].el.style.opacity = '1';
                signalElements.paths['second'].el.style.opacity = '0';
                signalElements.paths['third'].el.style.opacity = '0';
                signalElements.paths['fourth'].el.style.opacity = '0';
                break;
            case '1':
                signalElements.paths['first'].el.style.opacity = '1';
                signalElements.paths['second'].el.style.opacity = '0';
                signalElements.paths['third'].el.style.opacity = '0';
                signalElements.paths['fourth'].el.style.opacity = '0';
                break;
            case '2':
                signalElements.paths['first'].el.style.opacity = '1';
                signalElements.paths['second'].el.style.opacity = '1';
                signalElements.paths['third'].el.style.opacity = '0';
                signalElements.paths['fourth'].el.style.opacity = '0';
                break;
            case '3':
                signalElements.paths['first'].el.style.opacity = '1';
                signalElements.paths['second'].el.style.opacity = '1';
                signalElements.paths['third'].el.style.opacity = '1';
                signalElements.paths['fourth'].el.style.opacity = '0';
                break;
            case '0':
                signalElements.paths['first'].el.style.opacity = '1';
                signalElements.paths['second'].el.style.opacity = '1';
                signalElements.paths['third'].el.style.opacity = '1';
                signalElements.paths['fourth'].el.style.opacity = '1';
                break;
        
            default:
                break;
        }
    }
    

    function createElement(div){
        var container = document.createElement('object');
        var container2 = document.createElement('object');
        container.setAttribute('type', 'image/svg+xml');
        container.data = 'images/signal.svg';
        container.style.pointerEvents = 'none';
        container.id = div.id + "SVG";
        container.style.zIndex = '2';
        container2.style.position = 'absolute';

        container2.setAttribute('type', 'image/svg+xml');
        container2.data = 'images/signal.svg';
        container2.style.pointerEvents = 'none';
        container2.id = div.id + "SVG2";
        container2.style.position = 'absolute';
        container2.style.left = '0';
        container2.style.zIndex = '-1';

        div.appendChild(container);
        div.appendChild(container2);
        container.addEventListener("load", getElementPaths, this);
        container2.addEventListener("load", getElementBGPaths, this);
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.create = function(div) {
            return createElement(div);
        };
        externalMethods.updateStyles = function(name, value){
            return updateStyles(name, value);
        };
        externalMethods.getsignalElements = function () {
            return signalElements;
        }
        externalMethods.update = function (value) {
            update(value);
        }
        externalMethods.remove = function() {
            reset();
        };
        return externalMethods;
    }
    window.signalElement = initExternalMethods();
}(window, document));


/* LOTTI */

(function(window, doc) {
    // https://assets9.lottiefiles.com/datafiles/MUp3wlMDGtoK5FK/data.json
    // https://assets5.lottiefiles.com/datafiles/zc3XRzudyWE36ZBJr7PIkkqq0PFIrIBgp4ojqShI/newAnimation.json

    function getAssets(div){
        var lottieAssets = {
            playerElement: null,
            playerJS: null,
            storedValues: null,
        };
        lottieAssets.playerElement = div.querySelector('lottie-player');
        lottieAssets.playerElement.className = 'lottiePlayer';
        lottieAssets.playerJS = lottieAssets.playerElement.getLottie();
        lottieAssets.storedValues = action.savedElements.placedElements[div.id];
        return lottieAssets;
    }

    function updateURL(div){
        var assets = getAssets(div);
        if(assets.storedValues){
            if(assets.storedValues['lotti-url']){
                assets.playerElement.src = assets.storedValues['lotti-url'];
                //assets.playerElement.load(assets.storedValues['lotti-url']);
            }
        }
    }

    var playTimer = null;

    function updatePlayer(div, manualStateFromButton, playTimeout){
        updateURL(div);
        var assets = getAssets(div);
        var playState = assets.storedValues['playstate'];
            playState = (manualStateFromButton) ? manualStateFromButton : playState;

        function clearTimer(){
            if(playTimer){
                clearTimeout(playTimer);
            }
        }
        if(playState.includes('seek')){
            value = playState.split('(')[1];
            setTimeout(function(){
                assets.playerElement.seek(value.replace(')', ''));
                assets.playerElement.pause();
            },0);
        }
        switch (playState) {
            case 'pause':
                assets.playerElement.pause();
                break;
            case 'stop':
                clearTimer();
                assets.playerElement.removeAttribute('loop');
                assets.playerElement.removeAttribute('autoplay');
                assets.playerElement.style.opacity = "0";
                assets.playerElement.stop();
            break;
            case 'loop':
                clearTimer();
                assets.playerElement.setAttribute('autoplay', '');
                assets.playerElement.setAttribute('loop', '');
                assets.playerElement.style.opacity = "1";
                assets.playerElement.play();
            break;
            case 'play':
                clearTimer();
                assets.playerElement.removeAttribute('loop');
                assets.playerElement.setAttribute('autoplay', '');
                assets.playerElement.style.opacity = "1";
                assets.playerElement.play();

                if(playTimeout.lottieanistop){
                    if(playTimeout.lottieanistop  != 'null'){
                        playTimer = setTimeout(function(){
                            assets.playerElement.style.opacity = "0";
                            updatePlayer(div, 'stop', null);
                        }, playTimeout.lottieanistop);
                    }
                }

                if(playTimeout.lottieanipause){
                    if(playTimeout.lottieanipause  != 'null'){
                        playTimer = setTimeout(function(){
                            //assets.playerElement.style.opacity = "0";
                            updatePlayer(div, 'pause', null);
                        }, playTimeout.lottieanipause);
                    }
                }

                break;
            case 'loop':
                clearTimer();
                assets.playerElement.setAttribute('loop', '');
                assets.playerElement.setAttribute('autoplay', '');
                assets.playerElement.style.opacity = "1";
                assets.playerElement.play();
                break;
            default:
                break;
        }
        
    }

    function playLottie(div, playTimeout){
        updatePlayer(div, 'play', playTimeout);
    }

    function stopLottie(div, playTimeout){
        updatePlayer(div, 'stop', playTimeout);
    }

    function loopLottie(div, playTimeout){
        updatePlayer(div, 'loop', playTimeout);
    }

    function pauseLottie(div, playTimeout){
        updatePlayer(div, 'pause', playTimeout);
    }

    function seekLottie(div, playTimeout){
        var assets = getAssets(div);
        if(playTimeout.lottiestate){
            playState = playTimeout.lottiestate;
            if(playState.includes('seek')){
                value = playState.split('(')[1];
                setTimeout(function(){
                    assets.playerElement.seek(value.replace(')', ''));
                    assets.playerElement.pause();
                },0);
            }
        }
    }

    function loadDefaultLottie(div){
        var lottiPlayer = document.createElement('lottie-player');
        lottiPlayer.setAttribute('background', 'transparent');
        lottiPlayer.setAttribute('speed', '1');
        lottiPlayer.style.pointerEvents = 'none';
        lottiPlayer.src = "https://assets5.lottiefiles.com/datafiles/zc3XRzudyWE36ZBJr7PIkkqq0PFIrIBgp4ojqShI/newAnimation.json";
        div.appendChild(lottiPlayer);
        updatePlayer(div);
    }

    function createElement(div){
        var lottiPlayer = div.querySelector('lottie-player');
        if(!lottiPlayer){
            loadDefaultLottie(div);
        }else{
            updatePlayer(div);
        }
    }

    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.create = function(div, obj) {
            return createElement(div, obj);
        };
        externalMethods.updateURL = function(div) {
            return updateURL(div);
        };
        externalMethods.playLottie = function(div, playTimeout){
            return playLottie(div, playTimeout);
        }
        externalMethods.stopLottie = function(div, playTimeout){
            return stopLottie(div, playTimeout);
        }
        externalMethods.loopLottie = function(div, playTimeout){
            return loopLottie(div, playTimeout);
        }
        externalMethods.pauseLottie = function(div, playTimeout){
            return pauseLottie(div, playTimeout);
        }
        externalMethods.seekLottie = function(div, playTimeout){
            return seekLottie(div, playTimeout);
        }
        return externalMethods;
    }
    window.lottiElement = initExternalMethods();
}(window, document));



/* Hexagon */

(function(window, doc) {

    function degreesToRadians(angleInDegrees) {
        return (Math.PI * angleInDegrees) / 180;
    }

    function range(count) {
        return Array.from(Array(count).keys());
    }

    function pts(sideCount, radius) {
        var angle = 360 / sideCount;
        var vertexIndices = range(sideCount);
        var offsetDeg = 90 - ((180 - angle) / 2);
        var offset = degreesToRadians(offsetDeg);
    
        return vertexIndices.map((index) => {
        return {
            theta: offset + degreesToRadians(angle * index),
            r: radius,
        };
        });
    }

    function polygon([cx, cy], sideCount, radius) {
        return pts(sideCount, radius)
        .map(({ r, theta }) => [
            cx + r * Math.cos(theta), 
            cy + r * Math.sin(theta),
        ])
        .join(' '); 
    }

    function generateShape(div){
        var savedSides = null;
        if(action.savedElements.placedElements[div.id]['hexside']){
            savedSides = action.savedElements.placedElements[div.id]['hexside'];
        }
        var sideCount = 6;
        if(savedSides){
            sideCount = Number(savedSides);
        }
        var radius = 100;
        var svg = div.children[0];
        var points = svg.children[0];
        var s = 2 * radius + 50;
        var viz = polygon([s / 2, s / 2], sideCount, radius);
        svg.setAttribute('viewBox', '0 0 '+s+' '+s);
        points.setAttribute('points', viz);
    }

    function createElement(div){
        div.className = 'hexagon';
        var fillcolor = action.savedElements.placedElements[div.id]['hexfill'];
        var bordercolor = action.savedElements.placedElements[div.id]['hexbordercolor'] || 'transparent';
        var hexborder = action.savedElements.placedElements[div.id]['hexborder'];
        div.innerHTML = '<svg class="" viewBox="0 0 800 800" stroke="'+bordercolor+'" fill="'+fillcolor+'" stroke-width="'+hexborder+'" stroke-linecap="round" stroke-linejoin="round"><polygon points="" /></svg>';
        generateShape(div);
        return div;
    }
   
    function initExternalMethods() {
        var externalMethods = {};
        externalMethods.create = function(div) {
            return createElement(div);
        };

        return externalMethods;
    }
    window.hexagon = initExternalMethods();
}(window, document));
