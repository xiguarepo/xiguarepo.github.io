

// drawerOptions.create();

(function(window, doc) {

    var drawerOptionsButtons = {
        name: "Drawer Options",
        colors: function(){
            basicWindow.removeWindowById('drawerOptions');
            var inputs = [{
                innerHTML: "Badge Background Color",
                tag: 'badgeBackgroundColorDrawer',
                saveName: 'badgeBackgroundColorDrawer',
                defaultColor: 'red',
                onChange: function(value){
                    //lStorage.enablecolorbadges = null;
                    addStyleString('.icon_badge{background-color:'+value+'!important;}', 'badgeBackgroundColorDrawer');  
                    lStorage['badgeBackgroundColorDrawer'] = value;
                    lStorage.saveStorage();
                }
            },
            {
                innerHTML: "Badge Text Color",
                tag: 'badgeTextColorDrawer',
                saveName: 'badgeTextColorDrawer',
                defaultColor: 'white',
                onChange: function(value){
                    addStyleString('.icon_badge{color:'+value+'!important;}', 'badgeTextColorDrawer');
                    lStorage['badgeTextColorDrawer'] = value;
                    lStorage.saveStorage();  
                }
            },
            {
                innerHTML: "Label Text Color",
                tag: 'labelTextColorDrawer',
                saveName: 'labelTextColorDrawer',
                defaultColor: 'white',
                onChange: function(value){
                    addStyleString('.icon_label{color:'+value+'!important;}', 'labelTextColorDrawer');
                    lStorage['labelTextColorDrawer'] = value;
                    lStorage.saveStorage();  
                }
            },
            {
                innerHTML: "Shortcut Text Color",
                tag: 'shortcutTextColorDrawer',
                saveName: 'shortcutTextColorDrawer',
                defaultColor: 'white',
                onChange: function(value){
                    addStyleString('.shortcutHolder{color:'+value+'!important;}', 'shortcutTextColorDrawer');
                    lStorage['shortcutTextColorDrawer'] = value;
                    lStorage.saveStorage();  
                }
            },
            {
                innerHTML: "Shortcut BG Color",
                tag: 'shortcutBGDrawer',
                saveName: 'shortcutBGDrawer',
                defaultColor: 'rgba(0,0,0,0.4)',
                onChange: function(value){
                    addStyleString('.shortcutHolder{background-color:'+value+'!important;}', 'shortcutBGDrawer');
                    lStorage['shortcutBGDrawer'] = value;
                    lStorage.saveStorage();  
                }
            },
            {
                innerHTML: "Shortcut Icon Text Color",
                tag: 'shortcutIconTextDrawer',
                saveName: 'shortcutIconTextDrawer',
                defaultColor: 'white',
                onChange: function(value){
                    addStyleString('.drawerFolderIcon::after{color:'+value+'!important;}', 'shortcutIconTextDrawer');
                    lStorage['shortcutIconTextDrawer'] = value;
                    lStorage.saveStorage();  
                }
            },
            {
                innerHTML: "Shortcut Icon BG Color",
                tag: 'shortcutIconBGDrawer',
                saveName: 'shortcutIconBGDrawer',
                defaultColor: 'white',
                onChange: function(value){
                    addStyleString('.shortcutFolderHolder{background-color:'+value+'!important;}', 'shortcutIconBGDrawer');
                    lStorage['shortcutIconBGDrawer'] = value;
                    lStorage.saveStorage();  
                }
            }];
            colorInputs.createInput(inputs, 'Drawer Colors', 'drawerOptions');
        },
        toggles: function(){
            function windowWillRemove(){
                console.log('test');
            }
            basicWindow.removeAllWindows();
            var toggleWindow = basicWindow.makeWindow({
                title: 'Drawer Toggles',
                id: 'toggleWindow',
                className: 'toggleWindow drawerToggleWindow',
                width: 300,
                height: 300,
                center: true,
                bgcolor: 'transparent',
                backButton:true,
                backTo: function(){
                    createMenu();
                },
                beforeRemove: windowWillRemove,
            });
            
            var toggles = [{
                innerHTML: "Show shortcut menu",
                tag: 'showshortcutmenu',
                saveName: 'showshortcutmenu',
                onChange: function(obj, boolVal){
                    basicWindow.removeWindowById('drawerOptions');
                    lStorage['showshortcutmenu'] = boolVal;
                    lStorage.saveStorage();
                }
            },
            {
                innerHTML: "Use custom icons",
                tag: 'nocustomdrawericons',
                saveName: 'nocustomdrawericons',
                onChange: function(obj, boolVal){
                    basicWindow.removeWindowById('drawerOptions');
                    lStorage['nocustomdrawericons'] = boolVal;
                    lStorage.saveStorage();
                    FPDrawer.reloadDrawer();
                }
            },
            {
                innerHTML: "Hide labels",
                tag: 'hidedrawerlabels',
                saveName: 'hidedrawerlabels',
                onChange: function(obj, boolVal){
                    basicWindow.removeWindowById('drawerOptions');
                    lStorage['hidedrawerlabels'] = boolVal;
                    lStorage.saveStorage();
                    FPDrawer.reloadDrawer();
                }
            },
            {
                innerHTML: "Hide badges",
                tag: 'hidedrawerbadges',
                saveName: 'hidedrawerbadges',
                onChange: function(obj, boolVal){
                    basicWindow.removeWindowById('drawerOptions');
                    lStorage['hidedrawerbadges'] = boolVal;
                    lStorage.saveStorage();
                    FPDrawer.reloadDrawer();
                }
            },
            {
                innerHTML: "Use current badge style",
                tag: 'usecurrentbadges',
                saveName: 'usecurrentbadges',
                onChange: function(obj, boolVal){
                    basicWindow.removeWindowById('drawerOptions');
                    lStorage['usecurrentbadges'] = boolVal;
                    lStorage.saveStorage();
                    FPDrawer.reloadDrawer();
                }
            },
            {
                innerHTML: "Use auto color badges",
                tag: 'drawercolorbadge',
                saveName: 'drawercolorbadge',
                onChange: function(obj, boolVal){
                    basicWindow.removeWindowById('drawerOptions');
                    lStorage['drawercolorbadge'] = boolVal;
                    lStorage.saveStorage();
                    FPDrawer.reloadDrawer();
                }
            }];
            toggleWindow.appendChild(toggleMaker.createToggle(toggles));
        },
        drawer_type: function(){
            function windowWillRemove(){
                console.log('test');
            }
            basicWindow.removeAllWindows();
            var toggleWindow = basicWindow.makeWindow({
                title: 'Drawer Type',
                id: 'drawerTypeWindow',
                className: 'drawerTypeWindow drawerTypeWindow',
                width: 300,
                height: 300,
                center: true,
                bgcolor: 'transparent',
                beforeRemove: windowWillRemove,
                backButton:true,
                backTo: function(){
                    createMenu();
                },
            });
            
            var toggles = [{
                innerHTML: "Standard Drawer",
                tag: 'standarddrawer',
                saveName: 'standarddrawer',
                onChange: function(obj, boolVal){
                    basicWindow.removeWindowById('drawerOptions');
                    if(boolVal){
                        lStorage['drawertype'] = 'standarddrawer';
                        lStorage['standarddrawer'] = true;
                        lStorage['verticaldrawer'] = null;
                        lStorage.saveStorage();
                        FPDrawer.reloadDrawer();
                        setTimeout(function(){
                            basicWindow.removeWindowById('drawerTypeWindow');
                            //alert("Standard drawer close button is on the bottom");
                        },300);
                    }else{
                        alert("To switch drawers toggle other option");
                    }
                }
            },
            {
                innerHTML: "Vertical Drawer",
                tag: 'verticaldrawer',
                saveName: 'verticaldrawer',
                onChange: function(obj, boolVal){
                    basicWindow.removeWindowById('drawerOptions');
                    if(boolVal){
                        lStorage['drawertype'] = 'verticaldrawer';
                        lStorage['standarddrawer'] = null;
                        lStorage['verticaldrawer'] = true;
                        lStorage.saveStorage();
                        FPDrawer.reloadDrawer();
                        setTimeout(function(){
                            basicWindow.removeWindowById('drawerTypeWindow');
                            //alert("Vertical drawer close button is on the right");
                        },300);
                    }else{
                        alert("To switch drawers toggle other option");
                    }
                }
            }];
            toggleWindow.appendChild(toggleMaker.createToggle(toggles));
        }
    };

    function createMenu(){
        basicWindow.removeAllWindows();
        cloudWindow.removeCloud();
        var mainWindow = basicWindow.makeWindow({
            title: drawerOptionsButtons.name,
            id: 'drawerOptions',
            className: 'drawerOptions',
            width: 300,
            height: 150,
            bgcolor: 'transparent',
            color: 'white',
            center: true,
            backButton:true,
            backTo: function(){
                mainMenu.create();
            },
            beforeRemove: function(){
                cloudWindow.removeCloud();
            }
        });
        cloudWindow.makeCloud({
            parentWindow: mainWindow,
            cloudItems: drawerOptionsButtons,
            id: 'drawerOptionsCloud'
        });
    }


    function initExternalMethods(){
        var externalMethods = {};
        externalMethods.create = function(bundle){
            createMenu(bundle);
        };
        return externalMethods;
    }
    window.drawerOptions = initExternalMethods();
}(window, document));
